<p align="center"><img src="public/assets/img/favicon1.png" width="200"></p>

## PMII Malang

# Perlu Dikerjakan

- Fetch + Paginasi JSON Artikel
- Aktivitas Publik User
- Perbaikan FE + UI

# Note

- RajaOngkir API masih perlu migrasi ke database app bukan ambil dari RajaOngkir langsung

