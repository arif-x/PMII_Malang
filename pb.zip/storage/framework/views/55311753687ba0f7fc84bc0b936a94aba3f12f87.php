<?php $__env->startSection('content'); ?>

<div class="mt-4">
	<h1 style="margin-bottom: 20px;">Postingan</h1>
	<!-- Button trigger modal -->
	<button type="button" class="btn btn-primary" data-toggle="modal" data-target=".bd-example-modal-lg">Filter</button>	
	<a href="/admin-komisariat/postingan/all" type="button" class="btn btn-primary">Reset</a>	
	<br />
	<br />

	<div style="width: 100%">
		<div class="">
			<table class="table table-bordered data-table table-responsive" style="width: 100% !important">
				<thead>
					<tr>
						<th width="5%">No</th>
						<th width="">Judul Post</th>
						<th width="">Jenis Post</th>
						<th width="">Tanggal Post</th>
						<th width="">Uploader</th>
						<th width="">Rayon</th>
						<th width="">Detail</th>
					</tr>
				</thead>
				<tbody>
				</tbody>
			</table>	
		</div>
	</div>
</div>


<div class="">
	<div class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
		<div class="modal-dialog modal-lg modal-dialog-centered">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title" id="exampleModalLabel">Filter</h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
				</div>
				<div class="modal-body">
					<form method="GET" action="/admin-komisariat/postingan/filter">
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label for="rayon" class="col-form-label">Rayon</label>
									<div class="">
										<select name="rayon" class="form-control" style="text-transform: uppercase;">
											<option value="">Pilih Rayon</option>
											<?php $__currentLoopData = $rayon; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<option value="<?php echo e($key); ?>"><?php echo e($value); ?></option>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</select>
									</div>
								</div>
							</div>					
						</div>

						<button type="submit" class="btn btn-primary" style="width:100%">Proses</button>						
					</form>
				</div>
			</div>
		</div>
	</div>
</div>

<script type="text/javascript">
	$(function () {
		$('.data-tables').hide();
		$.ajaxSetup({
			headers: {
				'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
			}
		});
		var table = $('.data-table').DataTable({
			processing: true,
			serverSide: true,
			ajax: "/admin-komisariat/postingan/filter?rayon=<?php echo e(app('request')->input('rayon')); ?>",
			columns: [
			{data: 'DT_RowIndex', name: 'DT_RowIndex'},
			{data: 'judul_post', name: 'judul_post'},
			{data: 'jenis', name: 'jenis'},
			{data: 'tanggal_post', name: 'tanggal_post'},
			{data: 'nama_lengkap', name: 'nama_lengkap'},
			{data: 'nama_rayon', name: 'nama_rayon'},
			{data: 'detail', name: 'detail', orderable: false, searchable: false},
			]
		});
	});
</script>

<script type="text/javascript">
	$('#postingan').addClass('active');
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.kom-slider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ariffudin/Laravel/pb/resources/views/komisariat/postingan-filter.blade.php ENDPATH**/ ?>