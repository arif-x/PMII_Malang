<?php $__env->startSection('content'); ?>
<div class="mt-5">
    <?php $__currentLoopData = $moduls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modul): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="header-single">
        <div class="img-single">
            <img class="img-fluid imgs" src="/storage/foto/<?php echo e($modul->foto_terbaru); ?>">
        </div>
        <div class="title-single">
            <h4>
                <span class="text-left"><?php echo e($modul->judul_post); ?></span>
            </h4>
            <span>By: <?php echo e($modul->nama_lengkap); ?></span><br>
            <span>Tags: <?php echo e($modul->jenis); ?></span><br>
            <span><?php echo e($modul->keterangan_post); ?></span>  
        </div>                
        <div class="simpan text-center text-primary">     
            <form id="he"></form>                                   
            <div id="div-0" style="display: none">
                <a id="kosong"><i class='bx bx-heart nav__icon text-primary' style="font-size: 4vh"></i><br>
                Simpan</a>
            </div>
            <div id="div-1" style="display: none">
                <a id="saveok"><i class='bx bxs-heart nav__icon text-primary' style="font-size: 4vh"></i><br>
                Hapus</a>
            </div>
        </div>

    </div>
    <div class="col-md-12 mt-4">
        <div class="embed-responsive embed-responsive-1by1">
            <embed class="embed-responsive-item" src="/storage/modul/<?php echo e($modul->file); ?>.<?php echo e($modul->format_post); ?>"></embed>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php if($save == "[]"): ?>
<script type="text/javascript">
    $('#div-0').css("display", "block");
    $('#div-1').css("display", "none");
</script>
<?php else: ?>
<script type="text/javascript">
    $('#div-1').css("display", "block");
    $('#div-0').css("display", "none");
</script>
<?php endif; ?>

<?php $__currentLoopData = $moduls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modul): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<script type="text/javascript">     
    $(function () {
        $(document).on("click", "#kosong", function(e) {
            e.preventDefault();
            $.ajax({
                data: $('#he').serialize(),
                url: "/module/save/<?php echo e($modul->id_post); ?>",
                type: "GET",
                dataType: 'json',
                success: function (data) {
                    $('#div-0').css("display", "none");
                    $('#div-1').css("display", "block");
                },
                error: function (data) {
                    $('#div-0').css("display", "none");
                    $('#div-1').css("display", "block");
                }
            });
        });

        $(document).on("click", "#saveok", function(e) {
            e.preventDefault();
            $.ajax({
                data: $('#he').serialize(),
                url: "/modul/remove/<?php echo e($modul->id_post); ?>",
                type: "GET",
                dataType: 'json',
                success: function (data) {
                    $('#div-1').css("display", "none");
                    $('#div-0').css("display", "block");
                },
                error: function (data) {
                    $('#div-1').css("display", "none");
                    $('#div-0').css("display", "block");
                }
            });
        });
    });
</script>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<script type="text/javascript">
    $('#modules').addClass('active');
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.slider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ariffudin/Laravel/pb/resources/views/users/modul-single.blade.php ENDPATH**/ ?>