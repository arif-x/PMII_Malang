<!DOCTYPE html>
<html>
<head>
    <title></title>
    <style type="text/css">
        table, th, td {
            border: 1px solid black;
        }

        table {
            border-collapse: collapse;
        }
    </style>
</head>
<body>
    <table>
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Lengkap</th>
            </tr>
            <tr>
                <td>1</td>
                <td>nama</td>
            </tr>
        </thead>
    </table>
</body>
</html><?php /**PATH /home/ariffudin/Laravel/pb/resources/views/test.blade.php ENDPATH**/ ?>