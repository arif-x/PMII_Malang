<?php $__env->startSection('content'); ?>
<div class="mt-5">
    <div class="col-md-12">
        <h2>Aktifitas Terbaru</h2>
    </div>
    <div class="gr">
        <div class="containers">
            <?php $__currentLoopData = $hist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="box">
                <div class="image">
                    <?php if($data->jenis_post == 1): ?>
                    <img src="/img/thumbnail_pdf.png" alt="">
                    <?php elseif($data->jenis_post == 2): ?>
                    <img src="/img/thumbnile_video.png" alt="">
                    <?php endif; ?>
                </div>
                <div class="name_job text-capitalize"><?php echo e($data->judul_post); ?></div>
                <div class="text-center text-capitalize">
                    <?php if($data->jenis_post == 1): ?>
                    Unggah Modul
                    <?php elseif($data->jenis_post == 2): ?>
                    Unggah Video
                    <?php endif; ?>
                    <br><?php echo e($data->tanggal_post); ?>                        
                </div>
                <div class="btns">
                    <?php if($data->jenis_post == 1): ?>
                    <a type="button" target="_blank" class="btn btn-primary" href="/module/<?php echo e($data->file); ?>.<?php echo e($data->format_post); ?>" style="width: 100%">Lihat</a>
                    <?php elseif($data->jenis_post == 2): ?>
                    <a type="button" target="_blank" class="btn btn-primary" href="/video/<?php echo e($data->file); ?>.<?php echo e($data->format_post); ?>" style="width: 100%">Lihat</a>
                    <?php endif; ?>                    
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>

<script type="text/javascript">
    $('#histories').addClass('active');
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.slider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ariffudin/Laravel/pb/resources/views/users/history.blade.php ENDPATH**/ ?>