<?php $__env->startSection('content'); ?>

<div class="mt-5">
		<div class="col-md-12 one-line">	
			<h2>Artikel</h2>
			<a href="https://sahabat.or.id/" type="button" class="btn btn-primary">Lihat Semua</a>
		</div>
	<div class="gr">
		<div class="containers">
			<?php
			foreach ($cuk['item_terbaru'] AS $d){
			?>
			<div class="boxs">
				<div class="div-1">
					<div class="image">
						<img src="https://sahabat.or.id/wp-content/uploads/<?php echo e($d['meta_value']); ?>" alt="">
					</div>
				</div>
				<div class="div-2 align-middle">
					<div class="name_job text-capitalize text-center">
						<?php echo e(mb_strimwidth($d['post_title'], 0, 30, "...")); ?>					
					</div>
					<div class="text-center text-capitalize">
						<?php echo e($d['user_login']); ?><br>
						<p class="text-center" style="font-size: 80%">
							<?php echo e($d['name']); ?>

						</p>
					</div>
				</div>
				<div class="btns">
					<a type="button" target="_blank" class="btn btn-primary" href="<?php echo e($d['guid']); ?>" style="width: 100%">Lihat</a>
				</div>
			</div>
			<?php
		}
		?>
	</div>
</div>
</div>

<div class="mt-3">
	<div class="col-md-12">
		<div class="col-md-12 one-line">	
			<h2>Modul</h2>
			<a href="/module" type="button" class="btn btn-primary">Lihat Semua</a>
		</div>
	</div>
	<div class="gr">
		<div class="containers">
			<?php $__currentLoopData = $moduls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="box">
				<div class="image">
					<img src="/img/thumbnail_pdf.png" alt="">
				</div>
				<div class="name_job text-capitalize"><?php echo e($data->judul_post); ?></div>
				<div class="text-center text-capitalize">					
					<?php echo e($data->nama_lengkap); ?><br>
					<p style="font-size: 80%" class="text-center">
						<?php if($data->jenis_post == 1): ?>
						Modul
						<?php elseif($data->jenis_post == 2): ?>
						Video
						<?php endif; ?>
					</p>
				</div>
				<div class="btns">
					<a type="button" target="_blank" class="btn btn-primary" href="/module/<?php echo e($data->file); ?>.<?php echo e($data->format_post); ?>" style="width: 100%">Lihat</a>
				</div>
			</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
	</div>
</div>

<hr>

<div class="mt-3">
	<div class="col-md-12">
		<div class="col-md-12 one-line">	
			<h2>Video</h2>
			<a href="/video" type="button" class="btn btn-primary">Lihat Semua</a>
		</div>
	</div>
	<div class="gr">
		<div class="containers">
			<?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="box">
				<div class="image">
					<img src="/img/thumbnile_video.png" alt="">
				</div>
				<div class="name_job text-capitalize"><?php echo e($data->judul_post); ?></div>
				<div class="text-center text-capitalize">					
					<?php echo e($data->nama_lengkap); ?><br>
					<p style="font-size: 80%" class="text-center">
						<?php if($data->jenis_post == 1): ?>
						Modul
						<?php elseif($data->jenis_post == 2): ?>
						Video
						<?php endif; ?>
					</p>
				</div>
				<div class="btns">
					<a type="button" target="_blank" class="btn btn-primary" href="/video/<?php echo e($data->file); ?>.<?php echo e($data->format_post); ?>" style="width: 100%">Lihat</a>
				</div>
			</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
	</div>
</div>

<script type="text/javascript">
	$('#home').addClass('active');
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.slider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ariffudin/Laravel/pb/resources/views/home.blade.php ENDPATH**/ ?>