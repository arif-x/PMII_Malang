<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width">
</head>
<body style="margin:0">
  	<?php $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modul): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div style="width: 100%; height: 100vh">
    	<embed id="frPDF" height="100%" width="100%" src="/storage/modul/<?php echo e($modul->post); ?>.<?php echo e($modul->format_post); ?>"></embed>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</body>
</html><?php /**PATH /home/ariffudin/Laravel/pb/resources/views/users/pdf.blade.php ENDPATH**/ ?>