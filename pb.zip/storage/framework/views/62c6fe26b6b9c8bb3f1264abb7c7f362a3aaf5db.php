<!DOCTYPE html>
<html>
<head>
    <style type="text/css">
        table, th, td {
            border: 1px solid black;
        }

        table {
            border-collapse: collapse;
        }
    </style>
</head>
<body>
    <table>
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Lengkap</th>
                <th>Tanggal Lahir</th>
                <th>Jenis Kelamin</th>
                <th>Alamat Lengkap</th>
                <th>Provinsi</th>
                <th>Kota/Kabupaten</th>
                <th>Kecamatan</th>
                <th>Status Pernikahan</th>
                <th>Pendidikan Terakhir</th>
                <th>Pekerjaan</th>
                <th>No. HP</th>
            </tr>
        </thead>
        <tbody>
            <?php $no = 1 ?>
            <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($no++); ?></td>
                <td><?php echo e($data->nama_lengkap); ?></td>
                <td><?php echo e($data->tanggal_lahir); ?></td>
                <td><?php echo e($data->jenis_kelamin); ?></td>
                <td><?php echo e($data->alamat_lengkap); ?></td>
                <td><?php echo e($data->nama_prov); ?></td>
                <td><?php echo e($data->nama_kab); ?></td>
                <td><?php echo e($data->nama_kec); ?></td>
                <td><?php echo e($data->status_pernikahan); ?></td>
                <td><?php echo e($data->nama_pendidikan); ?></td>
                <td><?php echo e($data->nama_kerja); ?></td>
                <td><?php echo e($data->no_hp); ?></td>            
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html><?php /**PATH /home/ariffudin/Laravel/pb/resources/views/admin/export-excel/export-kader.blade.php ENDPATH**/ ?>