<?php

namespace App\Http\Controllers\AdminRayon\Postingan;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class DetailController extends Controller
{
    //
}
