<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class KaderisasiTerakhir extends Model
{
    protected $table = 'kaderisasi_terakhir';
}
