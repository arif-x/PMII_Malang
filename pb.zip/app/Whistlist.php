<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Whistlist extends Model
{
    protected $table = "save";
    protected $guarded = [];
}
