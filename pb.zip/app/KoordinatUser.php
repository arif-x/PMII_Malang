<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class KoordinatUser extends Model
{
    protected $table = "koordinat_user";
    protected $guarded = [];
}
