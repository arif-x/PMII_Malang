<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class KoordinatKab extends Model
{
    protected $table = "wilayah_koordinat_2";
}
