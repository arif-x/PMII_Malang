<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Kader extends Model
{
    protected $table = "profile";

    protected $guarded = [];
}
