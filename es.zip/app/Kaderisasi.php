<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Kaderisasi extends Model
{
    protected $table = "kaderisasi";

    protected $guarded = [];
}
