<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Komisariat extends Model
{
    protected $table = "komisariat";
}
