<p align="center"><img src="public/assets/img/favicon1.png" width="400"></p>

## PMII Malang

## Deploy & Run

How to Deploy and Run?

- Clone this repository
- Run "composer install".
- Set your database configuration in .env file
- Create database and give name with same name in .env file
- Refresh app key "php artisan key:generate"
- Run database migration "php artisan migrate"
- Run app "php artisan serve"
- Enjoy
