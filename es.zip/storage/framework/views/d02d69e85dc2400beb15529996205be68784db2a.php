<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="container mt-5">
            <div class="card">

                <div class="card-body">

                    <div class="" style="background-color: #fff">
                        <div class="row">
                            <div class="col-md-6 mt-2 mb-3">
                                <h3>Profil</h3>
                                <p>Data Profile <?php echo e(Auth::user()->name); ?></p>
                            </div>
                            <div class="col-md-6" style="text-align: right; margin-top: auto; margin-bottom: auto">
                                <button class="btn btn-info mb-3" style="">
                                    <i class="fa fa-arrow-left"></i> kembali
                                </button>
                                <button class="btn btn-primary mb-3" style="">
                                    <i class="fa fa-save"></i> Simpan
                                </button>
                            </div>
                        </div>

                        <hr>
                    </div>

                    <form method="POST" action="/profile">
                        <?php echo csrf_field(); ?>                                                

                        <h3>I. Data Diri:</h3>
                        <div class="alert alert-warning" role="alert">
                            <div class="ml-3 centere">
                                <i class="fa fa-info-circle" style="font-size: 3em"></i> &emsp; Isian Wajib <nobr class="red-color">*</nobr>.
                            </div>
                        </div>

                        <?php $__currentLoopData = $profile; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="nik" class="col-form-label text-md-right">NIK <nobr class="red-color">*</nobr></label>

                                    <div class="">
                                        <input id="nik" type="number" class="form-control <?php $__errorArgs = ['nik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="nik" required autocomplete="new-nik" placeholder="NIK" value="<?php echo e($data->nik); ?>">
                                        <?php $__errorArgs = ['nik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="ktm" class="col-form-label text-md-right">KTM <nobr class="red-color">*</nobr></label>

                                    <div class="">
                                        <input id="ktm" type="number" class="form-control <?php $__errorArgs = ['ktm'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="ktm" required autocomplete="new-ktm" placeholder="NIM KTM"  value="<?php echo e($data->nim); ?>">

                                        <?php $__errorArgs = ['ktm'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="nama" class="col-form-label text-md-right">Nama <nobr class="red-color">*</nobr></label>

                                    <div class="">
                                        <input id="nama" type="text" class="form-control <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="nama" required autocomplete="new-nama"  placeholder="Nama" readonly value="<?php echo e(Auth::user()->name); ?>">
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="jenisKelamin" class="col-form-label text-md-right">Jenis Kelamin <nobr class="red-color">*</nobr></label>

                                    <div class="">
                                        <select class="custom-select" name="jenisKelamin" required>
                                            <?php if(is_null($data->kecamatan)): ?>
                                            <option value="">Pilih Jenis Kalamin</option>
                                            <option value="Laki-Laki">Laki-Laki</option>
                                            <option value="Perempuan">Perempuan</option>
                                            <?php else: ?> 
                                            <option value="<?php echo e($data->jenis_kelamin); ?>"><?php echo e($data->jenis_kelamin); ?></option>
                                            <option value="Laki-Laki">Laki-Laki</option>
                                            <option value="Perempuan">Perempuan</option>
                                            <?php endif; ?>                                            
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <label for="tempatLahir" class="col-form-label text-md-right">Tempat Lahir <nobr class="red-color">*</nobr></label>
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="validationTooltipUsernamePrepend" style="background: #3b5998"><i class="fa fa-map-marker" style="color: #fff"></i></span>
                                    </div>
                                    <input type="text" name="tempatLahir" class="form-control" id="validationTooltipUsername" placeholder="Tampat Lahir" required value="<?php echo e($data->tempat_lahir); ?>">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <label for="tanggalLahir" class="col-form-label text-md-right">Tanggal Lahir <nobr class="red-color">*</nobr></label>
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="validationTooltipUsernamePrepend" style="background: #3b5998"><i class="fa fa-calendar" style="color: #fff"></i></span>
                                    </div>
                                    <input type="date" name="tanggalLahir" class="form-control" id="validationTooltipUsername" placeholder="Tanggal Lahir" required value="<?php echo e($data->tanggal_lahir); ?>">
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="alamat" class="col-form-label text-md-right">Alamat <nobr class="red-color">*</nobr></label>

                                    <div class="">
                                        <input id="alamat" type="text" class="form-control <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="alamat" placeholder="Alamat" required autocomplete="new-alamat" value="<?php echo e($data->alamat_lengkap); ?>">
                                        <i><small>Sesuai KTP</small></i>

                                        <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                        </div>                        

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="provinsi" class="col-form-label text-md-right">Provinsi <nobr class="red-color">*</nobr></label>

                                    <div class="">
                                        <select name="provinsi" class="form-control">
                                            <?php if(is_null($data->provinsi)): ?>
                                            <option value="">Pilih Provinsi</option>
                                            <?php else: ?> 
                                            <option value="<?php echo e($data->prov_id); ?>"><?php echo e($data->prov_name); ?></option>
                                            <?php endif; ?>
                                            <?php $__currentLoopData = $provinsi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($key); ?>"><?php echo e($value); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="kabupaten" class="col-form-label text-md-right">Kabupaten/Kota <nobr class="red-color">*</nobr></label>

                                    <div class="">
                                        <select name="kabupaten" class="form-control">
                                            <?php if(is_null($data->kota_kabupaten)): ?>
                                            <option value="">Pilih Kabupaten</option>
                                            <?php else: ?> 
                                            <option value="<?php echo e($data->reg_id); ?>"><?php echo e($data->reg_name); ?></option>
                                            <?php endif; ?>
                                        </select>
                                        <i><small class="form-text text-muted">Pilih provinsi terelebih dahulu</small></i>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="kecamatan" class="col-form-label text-md-right">Kecamatan <nobr class="red-color">*</nobr></label>

                                    <div class="">
                                        <div class="">
                                            <select name="kecamatan" class="form-control">
                                                <?php if(is_null($data->kecamatan)): ?>
                                                <option value="">Pilih Kabupaten</option>
                                                <?php else: ?> 
                                                <option value="<?php echo e($data->dis_id); ?>"><?php echo e($data->dis_name); ?></option>
                                                <?php endif; ?>
                                            </select>
                                            <i><small class="form-text text-muted">Pilih kabupaten terelebih dahulu</small></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="kelurahan" class="col-form-label text-md-right">Desa/Kelurahan <nobr class="red-color">*</nobr></label>

                                    <div class="">
                                        <div class="">
                                            <select name="kelurahan" class="form-control">
                                                <?php if(is_null($data->desa_kelurahan)): ?>
                                                <option value="">Pilih Desa/Kelurahan</option>
                                                <?php else: ?> 
                                                <option value="<?php echo e($data->vil_id); ?>"><?php echo e($data->vil_name); ?></option>
                                                <?php endif; ?>
                                            </select>
                                            <i><small class="form-text text-muted">Pilih kecamatan terelebih dahulu</small></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="rt" class="col-form-label text-md-right">RT <nobr class="red-color">*</nobr></label>

                                    <div class="">
                                        <input id="rt" type="number" class="form-control <?php $__errorArgs = ['rt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="rt" placeholder="RT" required autocomplete="new-rt">

                                        <?php $__errorArgs = ['rt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="rw" class="col-form-label text-md-right">RW <nobr class="red-color">*</nobr></label>

                                    <div class="">
                                        <input id="rw" type="number" class="form-control <?php $__errorArgs = ['rw'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="rw" placeholder="RW" required autocomplete="new-rw">

                                        <?php $__errorArgs = ['rw'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="komisariat" class="col-form-label text-md-right">Komisariat <nobr class="red-color">*</nobr></label>

                                    <div class="">
                                        <select name="komisariat" class="form-control">
                                            <?php if(is_null($data->komisariat)): ?>
                                            <option value="">Pilih Komisariat</option>
                                            <?php else: ?> 
                                            <option value="<?php echo e($data->id_komisariat); ?>"><?php echo e($data->nama_komisariat); ?></option>
                                            <?php endif; ?>
                                            <?php $__currentLoopData = $komisariat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($key); ?>"><?php echo e($value); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="rayon" class="col-form-label text-md-right">Rayon <nobr class="red-color">*</nobr></label>

                                    <div class="">
                                        <select name="rayon" class="form-control">
                                            <?php if(is_null($data->rayon)): ?>
                                            <option value="">Pilih Rayon</option>
                                            <?php else: ?> 
                                            <option value="<?php echo e($data->id_rayon); ?>"><?php echo e($data->nama_rayon); ?></option>
                                            <?php endif; ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="fakultas" class="col-form-label text-md-right">Fakultas <nobr class="red-color">*</nobr></label>

                                    <div class="">
                                        <input id="fakultas" type="text" class="form-control <?php $__errorArgs = ['fakultas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Fakultas" name="fakultas" required autocomplete="new-fakultas" value="<?php echo e($data->fakultas); ?>">

                                        <?php $__errorArgs = ['fakultas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="pendidikan" class="col-form-label text-md-right">Pendidikan Terakhir <nobr class="red-color">*</nobr></label>

                                    <div class="">
                                        <input id="pendidikan" type="text" class="form-control <?php $__errorArgs = ['pendidikan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Pendidikan" name="pendidikan" required autocomplete="new-pendidikan"  value="<?php echo e($data->pendidikan_terakhir); ?>">

                                        <?php $__errorArgs = ['pendidikan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="statusKawin" class="col-form-label text-md-right">Status Kawin <nobr class="red-color">*</nobr></label>

                                    <div class="">
                                        <select class="custom-select" name="statusKawin" required>
                                            <?php if(is_null($data->status_pernikahan)): ?>
                                            <option value="">Pilih Status Perkawinan</option>
                                            <?php else: ?> 
                                            <option value="<?php echo e($data->status_pernikahan); ?>"><?php echo e($data->status_pernikahan); ?></option>
                                            <?php endif; ?>                                            
                                            <option value="kawin">Kawin</option>
                                            <option value="belum kawin">Belum Kawin</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="pekerjaan" class="col-form-label text-md-right">Pekerjaan <nobr class="red-color">*</nobr></label>

                                    <div class="">
                                        <select name="pekerjaan" class="form-control">
                                            <?php if(is_null($data->pekerjaan)): ?>
                                            <option value="">Pilih Pekerjaan</option>
                                            <?php else: ?> 
                                            <option value="<?php echo e($data->id_kerja); ?>"><?php echo e($data->nama_kerja); ?></option>
                                            <?php endif; ?>                                            
                                            <?php $__currentLoopData = $pekerjaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($key); ?>"><?php echo e($value); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="golonganDarah" class="col-form-label text-md-right">Golongan Darah <nobr class="red-color">*</nobr></label>

                                    <div class="">
                                        <select class="custom-select" name="golonganDarah" required>
                                            <?php if(is_null($data->gol_darah)): ?>
                                            <option value="">Pilih Golongan Darah</option>
                                            <?php else: ?> 
                                            <option value="<?php echo e($data->gol_darah); ?>"><?php echo e($data->gol_darah); ?></option>
                                            <?php endif; ?> 
                                            <option value="o">O</option>
                                            <option value="a">A</option>
                                            <option value="b">B</option>
                                            <option value="ab">AB</option>
                                            <option value="tidak tahu">Tidak Tahu</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="noHp" class="col-form-label text-md-right">No. HP <nobr class="red-color">*</nobr></label>

                                    <div class="">
                                        <input id="noHp" type="number" class="form-control <?php $__errorArgs = ['noHp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="noHp" placeholder="No. HP" required autocomplete="new-noHp" value="<?php echo e($data->no_hp); ?>">

                                        <?php $__errorArgs = ['noHp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="pasFoto" class="col-form-label text-md-right">Pas Foto <nobr class="red-color">*</nobr></label>

                                    <div class="">
                                        <input id="pasFoto" type="text" class="form-control <?php $__errorArgs = ['pasFoto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Pas Foto" name="pasFoto" required autocomplete="new-pasFoto" value="<?php echo e($data->foto_terbaru); ?>">

                                        <?php $__errorArgs = ['pasFoto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <hr>
                        <br>

                        <h2>II. Data Kaderisasi:</h2>

                        <div class="alert alert-primary" role="alert">
                            <div class="ml-3 centere">
                                <i class="fa fa-info-circle" style="font-size: 3em"></i> &emsp; Isian Kaderisasi.
                            </div>
                        </div>

                        <?php $__currentLoopData = $kaderisasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kader): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <h3>MAPABA:</h3>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="komisariatPenyelenggara" class="col-form-label text-md-right">Komisariat Penyelenggara <nobr class="red-color">*</nobr></label>

                                    <div class="">
                                        <div class="form-group">                    

                                            <div class="">
                                                <select name="komisariatPenyelenggara" class="form-control">
                                                    <?php if(is_null($kader->komisariat)): ?>
                                                    <option value="">Pilih komisariat Penyelenggara</option>
                                                    <?php else: ?> 
                                                    <option value="<?php echo e($kader->komisariat); ?>"><?php echo e($kader->nama_komisariat); ?></option>
                                                    <?php endif; ?>
                                                    <?php $__currentLoopData = $komisariat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($key); ?>"><?php echo e($value); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="rayonPenyelenggara" class="col-form-label text-md-right">Rayon Penyelenggara <nobr class="red-color">*</nobr></label>

                                    <div class="">
                                        <div class="form-group">                    

                                            <div class="">
                                                <select name="rayonPenyelenggara" class="form-control">
                                                    <?php if(is_null($kader->rayon)): ?>
                                                    <option value="">Pilih Rayon</option>
                                                    <?php else: ?> 
                                                    <option value="<?php echo e($kader->id_rayon); ?>"><?php echo e($kader->nama_rayon); ?></option>
                                                    <?php endif; ?>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="tahun" class="col-form-label text-md-right">Tahun Bergabung <nobr class="red-color">*</nobr></label>

                                    <div class="">
                                        <input id="tahun" type="number" class="form-control <?php $__errorArgs = ['tahun'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="tahun" placeholder="Tahun Bergabung" required autocomplete="new-tahun" value="<?php echo e($kader->tahun_bergabung); ?>">

                                        <?php $__errorArgs = ['tahun'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="angkatan" class="col-form-label text-md-right">Angkatan Ke <nobr class="red-color">*</nobr></label>

                                    <div class="">
                                        <input id="angkatan" type="number" class="form-control <?php $__errorArgs = ['angkatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="angkatan" placeholder="Angkatan Ke" required autocomplete="new-angkatan" value="<?php echo e($kader->angkatan_ke); ?>">

                                        <?php $__errorArgs = ['angkatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="kaderisasiTerakhir" class="col-form-label text-md-right">Kaderisasi Terakhir <nobr class="red-color">*</nobr></label>

                                    <div class="">
                                        <input id="kaderisasiTerakhir" type="text" class="form-control <?php $__errorArgs = ['kaderisasiTerakhir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="kaderisasiTerakhir" placeholder="Kaderisasi Terakhir" required autocomplete="new-kaderisasiTerakhir" value="<?php echo e($kader->kaderisasi_terakhir); ?>">

                                        <?php $__errorArgs = ['kaderisasiTerakhir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <hr>
                        <br>

                        <h2>III. Data Pendukung:</h2>

                        <div class="alert alert-success" role="alert">
                            <div class="ml-3 centere">
                                <i class="fa fa-info-circle" style="font-size: 3em"></i> &emsp; Isian Opsional, jika ada sebaiknya dilengkapi. Kosongkan jika tidak ada.
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <label for="noWa" class="col-form-label text-md-right">No. WA</label>
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="validationTooltipUsernamePrepend" style="background: #1BC5BD"><i class="fa fa-whatsapp" style="color: #fff"></i></span>
                                    </div>
                                    <input type="number" name="noWa" placeholder="08123456789" class="form-control" id="validationTooltipUsername">
                                </div>
                            </div>
                        </div>


                        <div class="row">
                            <div class="col-md-12">
                                <label for="email" class="col-form-label text-md-right">Email</label>
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="validationTooltipUsernamePrepend" style="background: #F64E60"><i class="fa fa-envelope" style="color: #fff"></i></span>
                                    </div>
                                    <input type="email" name="email" placeholder="username@gmail.com" class="form-control" id="validationTooltipUsername">                                    
                                </div>
                                <i><small class="form-text text-muted">Contoh: username@gmail.com</small></i>
                            </div>
                        </div>


                        <div class="row">
                            <div class="col-md-12">
                                <label for="facebook" class="col-form-label text-md-right">Facebook</label>
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="validationTooltipUsernamePrepend" style="background: #3b5998"><i class="fa fa-facebook" style="color: #fff"></i></span>
                                    </div>
                                    <input type="text" name="facebook" placeholder="facebook.com/username" class="form-control" id="validationTooltipUsername">
                                </div>
                                <i><small class="form-text text-muted">Contoh: facebook.com/username</small></i>
                            </div>
                        </div>


                        <div class="row">
                            <div class="col-md-12">
                                <label for="twitter" class="col-form-label text-md-right">Twitter</label>
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="validationTooltipUsernamePrepend" style="background: #1da1f2"><i class="fa fa-twitter" style="color: #fff"></i></span>
                                    </div>
                                    <input type="text" name="twitter" placeholder="twitter.com/username" class="form-control" id="validationTooltipUsername">
                                </div>
                                <i><small class="form-text text-muted">Contoh: twitter.com/username</small></i>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <label for="instagram" class="col-form-label text-md-right">Instagram</label>
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="validationTooltipUsernamePrepend" style="background: #e1306c"><i class="fa fa-instagram" style="color: #fff"></i></span>
                                    </div>
                                    <input type="text" name="instagram" placeholder="instagram.com/username" class="form-control" id="validationTooltipUsername">
                                </div>
                                <i><small class="form-text text-muted">Contoh: instagram.com/username</small></i>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <label for="linkedin" class="col-form-label text-md-right">LinkedIn</label>
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="validationTooltipUsernamePrepend" style="background: #0077b5"><i class="fa fa-linkedin" style="color: #fff"></i></span>
                                    </div>
                                    <input type="text" name="linkedin" placeholder="linkedin.com/in/username" class="form-control" id="validationTooltipUsername">
                                </div>
                                <i><small class="form-text text-muted">Contoh: linkedin.com/in/username</small></i>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <label for="fotoResmi" class="col-form-label text-md-right">Foto Resmi</label>
                                <div class="input-group">
                                    <input type="file" name="fotoResmi" class="form-control" id="fotoResmi">
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <label for="fotoKTP" class="col-form-label text-md-right">Foto KTP</label>
                                <div class="input-group">
                                    <input type="file" name="fotoKTP" class="form-control" id="fotoKTP">
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <label for="fotoKtm" class="col-form-label text-md-right">Foto KTM</label>
                                <div class="input-group">
                                    <input type="file" name="fotoKtm" class="form-control" id="fotoKtm">
                                </div>
                            </div>
                        </div>

                        
                        <div class="form-group row mb-0 mt-4">
                            <div class="col-md-12">
                                <button type="submit" class="btn btn-primary" style="width: 100%;">
                                    <i class="fa fa-save"></i> Simpan
                                </button>
                            </div>
                        </div>
                    </form>                    
                </div>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
    $(document).ready(function() {
        $('select[name="provinsi"]').on('change', function() {
            var provId = $(this).val();
            if(provId) {
                $.ajax({
                    url: '/get-regency/'+provId,
                    type: "GET",
                    dataType: "json",
                    success:function(data) {
                        $('select[name="kabupaten"]').empty();
                        $.each(data, function(key, value) {
                            $('select[name="kabupaten"]').append('<option value="'+ key +'">'+ value +'</option>');
                        });
                    }
                });
            } else {
                $('select[name="kabupaten"]').empty();
            }
        });
        $('select[name="kabupaten"]').on('change', function() {
            var kabId = $(this).val();
            if(kabId) {
                $.ajax({
                    url: '/get-district/'+kabId,
                    type: "GET",
                    dataType: "json",
                    success:function(data) {
                        $('select[name="kecamatan"]').empty();
                        $.each(data, function(key, value) {
                            $('select[name="kecamatan"]').append('<option value="'+ key +'">'+ value +'</option>');
                        });
                    }
                });
            } else {
                $('select[name="kecamatan"]').empty();
            }
        });
        $('select[name="kecamatan"]').on('change', function() {
            var kecId = $(this).val();                 
            if(kecId) {
                $.ajax({
                    url: '/get-village/'+ kecId,
                    type: "GET",
                    dataType: "json",
                    success:function(data) {
                        $('select[name="kelurahan"]').empty();
                        $.each(data, function(key, value) {
                            $('select[name="kelurahan"]').append('<option value="'+ key +'">'+ value +'</option>');
                        });
                    }
                });
            } else {
                $('select[name="kelurahan"]').empty();
            }
        });

        $('select[name="komisariat"]').on('change', function() {
            var komId = $(this).val();
            if(komId) {
                $.ajax({
                    url: '/get-rayon/'+komId,
                    type: "GET",
                    dataType: "json",
                    success:function(data) {
                        $('select[name="rayon"]').empty();
                        $.each(data, function(key, value) {
                            $('select[name="rayon"]').append('<option value="'+ key +'">'+ value +'</option>');
                        });
                    }
                });
            } else {
                $('select[name="rayon"]').empty();
            }
        });

        $('select[name="komisariatPenyelenggara"]').on('change', function() {
            var komId = $(this).val();
            if(komId) {
                $.ajax({
                    url: '/get-rayon/'+komId,
                    type: "GET",
                    dataType: "json",
                    success:function(data) {
                        $('select[name="rayonPenyelenggara"]').empty();
                        $.each(data, function(key, value) {
                            $('select[name="rayonPenyelenggara"]').append('<option value="'+ key +'">'+ value +'</option>');
                        });
                    }
                });
            } else {
                $('select[name="rayonPenyelenggara"]').empty();
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.slider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ariffudin/Laravel/pb/resources/views/profile/profile.blade.php ENDPATH**/ ?>