<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <link rel="shortcut icon" href="assets/img/favicon1.png" type="image/png">

    <!--=============== REMIXICONS ===============-->
    <link href="https://cdn.jsdelivr.net/npm/remixicon@2.5.0/fonts/remixicon.css" rel="stylesheet">
    <script src="<?php echo e(URL::asset('lib/jquery/jquery.min.js')); ?>"></script>


    <!--=============== SWIPER CSS ===============-->
    <link rel="stylesheet" href="<?php echo e(URL::asset('assets/css/swiper-bundle.min.css')); ?>">

    <!--=============== CSS ===============-->
    <link rel="stylesheet" href="<?php echo e(URL::asset('lib/bootstrap/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('lib/font-awesome/css/font-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('assets/css/styles.css')); ?>">

    <style type="text/css">
        .centere {
            display: flex;
            align-items: center;            
        }

        .form-control:focus {
            box-shadow:none;
        }

        .red-color {
            color: red;
        }

        select, .custom-select {
            text-transform: capitalize !important;
        }
    </style>
</head>
<body>
    <div id="app">

        <main class="py-4">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
    <!--========== SCROLL UP ==========-->
    <a href="#" class="scrollup" id="scroll-up">
        <i class="ri-arrow-up-line scrollup__icon"></i>
    </a>

    <!--=============== SCROLL REVEAL===============-->
    <script src="<?php echo e(URL::asset('assets/js/scrollreveal.min.js')); ?>"></script>

    <!--=============== SWIPER JS ===============-->
    <script src="<?php echo e(URL::asset('assets/js/swiper-bundle.min.js')); ?>"></script>
</body>
</html>
<?php /**PATH /home/ariffudin/Laravel/pb/resources/views/layouts/app.blade.php ENDPATH**/ ?>